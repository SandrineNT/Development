const express = require('express');
const res = require('express/lib/response');
const app = express();
const port = 3000;
const fs = require("fs")
const path = require("path");
const basicAuth = require('express-basic-auth');
const bcrypt = require("bcrypt");
const cookieParser = require('cookie-parser')
app.use(cookieParser());

/**
 * Authorizer function of basic auth, that handles encrypted passwords
 * @param {*} username Provided username
 * @param {*} password Provided password
 * @param {*} cb (error, isAuthorized)
 */
 

/**
 * CSV parsing (for files with a header and 2 columns only)
 *
 * @example: "name,school\nEric Burel, LBKE"
 * => [{ name: "Eric Burel", school: "LBKE"}]
 */
 const parseCsvWithHeader = (filepath, cb) => {
  const rowSeparator = "\n";
  const cellSeparator = ",";
  // example based on a CSV file
  fs.readFile(filepath, "utf8", (err, data) => {
    const rows = data.split(rowSeparator);
    // first row is an header I isolate it
    const [headerRow, ...contentRows] = rows;
    const header = headerRow.split(cellSeparator);

    const items = contentRows.map((row) => {
      const cells = row.split(cellSeparator);
      const item = {
        [header[0]]: cells[0],
        [header[1]]: cells[1],
      };
      return item;
    });
    return cb(null, items);
  });
};

const clearPasswordAuthorizer = (username, password, cb) => {
  // Parse the CSV file: this is very similar to parsing students!
  parseCsvWithHeader("./users-clear.csv", (err, users) => {
    console.log(users);
    // Check that our current user belong to the list
    const storedUser = users.find((possibleUser) => {
      // NOTE: a simple comparison with === is possible but less safe
      return basicAuth.safeCompare(username, possibleUser.username);
    });
    // NOTE: this is an example of using lazy evaluation of condition
    if (!storedUser || !basicAuth.safeCompare(password, storedUser.password)) {
      cb(null, false);
    } else {
      cb(null, true);
    }
  });
};
 
 


const encryptedPasswordAuthorizer = (username, password, cb) => {
  // Parse the CSV file: this is very similar to parsing students!
  parseCsvWithHeader("./users.csv", (err, users) => {
    // Check that our current user belong to the list
    const storedUser = users.find((possibleUser) => {
      // NOTE: a simple comparison with === is possible but less safe
      return basicAuth.safeCompare(possibleUser.username, username);
    });
    // NOTE: this is an example of using lazy evaluation of condition
    if (!storedUser) {
      // username not found
      cb(null, false);
    } else {
      // now we check the password
      // bcrypt handles the fact that storedUser password is encrypted
      // it is asynchronous, because this operation is long
      // so we pass the callback as the last parameter
      bcrypt.compare(password, storedUser.password, cb);
    }
  });
};

app.use(
  basicAuth({
    //users: {[process.env.ADMIN_USERNAME ]: process.env.ADMIN_PASSWORD },
    //challenge: true,
    authorizer: encryptedPasswordAuthorizer,
    authorizeAsync: true,
    challenge: true

  })
);



//app.use("/", (req,res) =>{
//  res.send("success");
//});


app.use(express.json());
app.use(express.urlencoded({ extended : true}));
app.set('views','./views'); 
app.set('view engine','ejs')
app.use(express.static("public"));
//app.get('/', (req, res) => {
  //res.sendFile(path.join(__dirname, "./views/home.html"))
//});




const getStudentsFromCsfile = (cb) => { 
  const rowSeparator = "\n";
  const cellSeparator = ",";
  fs.readFile('/home/snguemkam/epfbook/students.csv',"utf8", (err, data) => { 
    const rows = data.split(rowSeparator); 
    const [headerRow,...contentRows] = rows; 
    const header = headerRow.split(cellSeparator); 
    const students = contentRows.map((row)=>{
      const cells = row.split(cellSeparator); 
      const student = {
        [header[0]]:cells[0],
        [header[1]]:cells[1],
      };
	    return student;
	  }); 
	  return cb(null, students);
  }); 
};


app.get('/students2', (req, res) => {
  getStudentsFromCsfile((err, student) =>{
   if (err){
     console.error(err);
     res.send("ERROR");
    } 
     res.render("students.ejs", {students: [{ name: "Sandrine NGUEMKAM", school: "EPF"}]});
  });
});



//app.get('/', (req, res) => {
//  res.send('Hello The World!');
//  res.send([{ 
//	name: "Eric Burel",
//  	school: "EPF" }, 
//{ 	name: "Sandrine NGUEMKAM", 
//	school: "EPF"}]);
//})


const storeStudentInCsvFile = (student,cb) =>{
  const csvLine =`\n${student.name},${student.school}`;
  console.log(csvLine);
  fs.writeFile("./students.csv", csvLine,{flag: "a"} , (err) =>{
    cb(err, "ok");
  } );
}; 



app.get("/students/create", (req,res) =>{
  res.render("create-student");
} );


app.post("/students/create", (req,res) =>{
  console.log(req.body);
  const students = req.body;
  storeStudentInCsvFile(student, (err, storeResult) =>{
    if (err){
      res.redirect("/students/create?error=1");
    } else {
      res.redirect("/students/create?error=1");
    } 
  } );
} );

app.post("/api/login", (req, res) => {
  console.log("current cookies:", req.cookies);
  // We assume that you check if the user can login based on "req.body"
  // and then generate an authentication token
  const token = "FOOBAR";
  const tokenCookie = {
    path: "/",
    httpOnly: true,
    expires: new Date(Date.now() + 60 * 60 * 1000),
  };
  res.cookie("auth-token", token, tokenCookie);
  res.send("OK");
});


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
});
 
